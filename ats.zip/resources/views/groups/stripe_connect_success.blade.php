<x-app-layout>
    <section class=" p-4 rounded">
        <div class="text-center py-32">
            <h2 class="font-bold text-xl mb-6">You're Amazing</h2>
            <p>Stripe Connection Successful</p>
        </div>
    </section>
</x-app-layout>