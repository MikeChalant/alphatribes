<div class="flex justify-between items-center rounded-lg p-6 bg-white">
    <div class="space-y-3">
        <p class="text-3xl text-teal-500">{{ $counts }}</p>
        <p>{{ $label }}</p>
    </div>
    <div class="text-teal-500">{{ $logo }}</div>
</div>