<div class="my-3 flex justify-between">
    <h2 class="font-bold text-2xl">{{ $pageTitle }}</h2>
    <div>{{ $slot }}</div>
</div>