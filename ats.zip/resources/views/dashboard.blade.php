<x-app-layout>
    <x-page-heading>
        <x-slot name="pageTitle">{{ __('Dashboard') }}</x-slot>
    </x-page-heading>
    <section class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <x-dashboard-card>
            <x-slot name="counts">{{ $usersCount }}</x-slot>
            <x-slot name="label">Users</x-slot>
            <x-slot name="logo">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            </x-slot>
        </x-dashboard-card>
        <x-dashboard-card>
            <x-slot name="counts">{{ $groupsCount }}</x-slot>
            <x-slot name="label">Groups</x-slot>
            <x-slot name="logo">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg>
            </x-slot>
        </x-dashboard-card>
        <x-dashboard-card>
            <x-slot name="counts">2</x-slot>
            <x-slot name="label">Online Users</x-slot>
            <x-slot name="logo">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path></svg>
            </x-slot>
        </x-dashboard-card>
        <x-dashboard-card>
            <x-slot name="counts">{{ $privateGroupsCount }}</x-slot>
            <x-slot name="label">Private Groups</x-slot>
            <x-slot name="logo">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
            </x-slot>
        </x-dashboard-card>
        <x-dashboard-card>
            <x-slot name="counts">{{ $publicGroupsCount }}</x-slot>
            <x-slot name="label">Public Groups</x-slot>
            <x-slot name="logo">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 19v-8.93a2 2 0 01.89-1.664l7-4.666a2 2 0 012.22 0l7 4.666A2 2 0 0121 10.07V19M3 19a2 2 0 002 2h14a2 2 0 002-2M3 19l6.75-4.5M21 19l-6.75-4.5M3 10l6.75 4.5M21 10l-6.75 4.5m0 0l-1.14.76a2 2 0 01-2.22 0l-1.14-.76"></path></svg>
            </x-slot>
        </x-dashboard-card>
        <x-dashboard-card>
            <x-slot name="counts">60</x-slot>
            <x-slot name="label">User Countries</x-slot>
            <x-slot name="logo">
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"></path></svg>
            </x-slot>
        </x-dashboard-card>

    </section>
</x-app-layout>