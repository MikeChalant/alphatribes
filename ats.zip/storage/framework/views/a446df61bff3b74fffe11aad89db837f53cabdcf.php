<div class="flex justify-between items-center rounded-lg p-6 bg-white">
    <div class="space-y-3">
        <p class="text-3xl text-teal-500"><?php echo e($counts); ?></p>
        <p><?php echo e($label); ?></p>
    </div>
    <div class="text-teal-500"><?php echo e($logo); ?></div>
</div><?php /**PATH /var/www/html/alphatribesignals.com/resources/views/components/dashboard-card.blade.php ENDPATH**/ ?>