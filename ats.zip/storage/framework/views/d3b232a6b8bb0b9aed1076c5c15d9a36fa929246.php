<div class="my-3 flex justify-between">
    <h2 class="font-bold text-2xl"><?php echo e($pageTitle); ?></h2>
    <div><?php echo e($slot); ?></div>
</div><?php /**PATH /var/www/html/alphatribesignals/resources/views/components/page-heading.blade.php ENDPATH**/ ?>