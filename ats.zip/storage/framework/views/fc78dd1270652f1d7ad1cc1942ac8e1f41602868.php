<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.page-heading','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('pageTitle', null, []); ?> <?php echo e(__('Group Detail')); ?> <?php $__env->endSlot(); ?>
        <a class="flex items-center space-x-1 border px-3 py-1 rounded-lg" href="<?php echo e(route('admin.group.index')); ?>">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
            <span>Groups</span>
        </a>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <section class="bg-white p-4 rounded">
       <div class="px-4">
           <div class="flex flex-col py-6">
               <div class="w-20 h-20 rounded-full overflow-hidden">
                   <img src="<?php echo e($group->image ? asset('images/group_profile/'.$group->image) : asset('images/noimage.png')); ?>"
                    class="w-full rounded-full object-cover">
               </div>
               <h2 class="font-semibold mt-4"><?php echo e($group->group_name); ?></h2>
           </div>
           <div class="space-y-6">
               <div class="grid lg:grid-cols-6">
                   <p class="lg:col-span-1">Description:</p>
                    <P class="lg:col-span-5"><?php echo e($group->description); ?></P>
               </div>
               <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Support Email:</p>
                    <P class="lg:col-span-5"><?php echo e($group->support_email); ?></P>
               </div>
               <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Category:</p>
                    <P class="lg:col-span-5"><?php echo e($group->category->category_name); ?></P>
               </div>
               <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Group Type:</p>
                    <P class="lg:col-span-5"><?php echo e($group->group_type); ?> &amp; <?php echo e(($group->paid_group === '1') ? 'Paid' : 'Free'); ?></P>
               </div>
                <?php if($group->group_type === '1'): ?>
                <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Stripe Connect Email:</p>
                    <P class="lg:col-span-5"><?php echo e($group->stripe_connect_email); ?></P>
                </div>
                <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Payment Type:</p>
                    <P class="lg:col-span-5"><?php echo e($group->payment_type); ?></P>
                </div>
                <?php if($group->payment_type === 'recurring'): ?>
                    <div class="grid lg:grid-cols-6">
                        <p class="lg:col-span-1">Daily Cost:</p>
                        <P class="lg:col-span-5"><?php echo e($group->billing_currency); ?> <?php echo e($group->daily_cost); ?></P>
                    </div>
                    <div class="grid lg:grid-cols-6">
                        <p class="lg:col-span-1">Weekly Cost:</p>
                        <P class="lg:col-span-5"><?php echo e($group->billing_currency); ?> <?php echo e($group->weekly_cost); ?></P>
                    </div>
                    <div class="grid lg:grid-cols-6">
                        <p class="lg:col-span-1">Monthly Cost:</p>
                        <P class="lg:col-span-5"><?php echo e($group->billing_currency); ?> <?php echo e($group->monthly_cost); ?></P>
                    </div>
                    <div class="grid lg:grid-cols-6">
                        <p class="lg:col-span-1">Yearly Cost:</p>
                        <P class="lg:col-span-5"><?php echo e($group->billing_currency); ?> <?php echo e($group->yearly_cost); ?></P>
                    </div>
                <?php else: ?>
                    <div class="grid lg:grid-cols-6">
                        <p class="lg:col-span-1">Onetime Cost:</p>
                        <P class="lg:col-span-5"><?php echo e($group->onetime_cost); ?></P> 
                    </div>
                <?php endif; ?>
                <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Trial Duration:</p>
                    <P class="lg:col-span-5"><?php echo e($group->trial_duration); ?></P>
                </div>
               <?php endif; ?>
               <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Total Subscribers:</p>
                    <P class="lg:col-span-5"><?php echo e($group->total_subscribers); ?></P>
               </div>
               <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Report Count:</p>
                    <P class="lg:col-span-5"><?php echo e($group->total_subscribers); ?></P>
               </div>
               <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">File Count:</p>
                    <P class="lg:col-span-5"><?php echo e($group->file_count); ?></P>
               </div>
               <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Audio Count:</p>
                    <P class="lg:col-span-5"><?php echo e($group->audio_count); ?></P>
               </div>
               <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Video Count:</p>
                    <P class="lg:col-span-5"><?php echo e($group->video_count); ?></P>
               </div>
               <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Created:</p>
                    <P class="lg:col-span-5"><?php echo e(date('M d, Y H:i A', strtotime($group->created_at))); ?></P>
               </div>
               <div class="grid lg:grid-cols-6">
                    <p class="lg:col-span-1">Created By:</p>
                    <P class="lg:col-span-5"><?php echo e($group->user->name); ?></P>
               </div>
               <div class="grid lg:grid-cols-6">
               <p><a href="<?php echo e(route('admin.group.delete', $group->id)); ?>" class="font-medium text-gray-600 dark:text-gray-500 hover:underline"
                    onclick="confirmDelete(event,'deleteGroupForm<?php echo e($group->id); ?>', 'Delete Group')"
                    >
                    <form id="deleteGroupForm<?php echo e($group->id); ?>" action="<?php echo e(route('admin.group.delete', $group->id)); ?>" method="post">
                        <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?></form>
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    </a>
                </p>
               </div>
           </div>
       </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /var/www/html/alphatribesignals/resources/views/groups/show.blade.php ENDPATH**/ ?>