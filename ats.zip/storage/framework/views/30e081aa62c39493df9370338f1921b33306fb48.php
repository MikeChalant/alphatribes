<?php if(session()->has('alert') && session()->get('alert') === 'success'): ?>
<script>
        let successMsg = '<?php echo e(session("message")); ?>';
        Notiflix.Notify.success(successMsg);
</script>
<?php endif; ?>

<?php if(session()->has('alert') && session()->get('alert') === 'failure'): ?>
<script type="text/javascript">
        let failureMsg = '<?php echo e(session("message")); ?>';
        Notiflix.Notify.failure(failureMsg);
</script>
<?php endif; ?>

<?php if(session()->has('alert') && session()->get('alert') === 'warning'): ?>
<script type="text/javascript">
        let warningMsg = '<?php echo e(session("message")); ?>';
        Notiflix.Notify.warning(warningMsg);
</script>
<?php endif; ?>

<?php if(session()->has('alert') && session()->get('alert') === 'info'): ?>
<script type="text/javascript">
        let infoMsg = '<?php echo e(session("message")); ?>';
        Notiflix.Notify.info(infoMsg);
</script>
<?php endif; ?>
<?php /**PATH /var/www/html/alphatribesignals.com/resources/views/flash_message.blade.php ENDPATH**/ ?>