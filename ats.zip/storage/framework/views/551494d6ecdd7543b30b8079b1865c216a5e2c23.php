<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.page-heading','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('page-heading'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('pageTitle', null, []); ?> <?php echo e(__('Payment Option')); ?> <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <section class="bg-white p-4 rounded">
        <form id="allow_trial_form" onsubmit="allowTrial(event)" method="POST" action="<?php echo e(route('admin.group.save_payment_option', $groupId)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('patch'); ?>
            <div class="flex mb-6 space-x-6">
                <div class="flex items-center pl-4">
                    <input <?php if(old('payment_option') && old('payment_option') === 'onetime'): ?> checked <?php endif; ?> 
                    <?php if(!old('payment_option')): ?> checked <?php endif; ?> id="onetime" onchange="togglePaymentOption(event)" 
                    type="radio" value="onetime" name="payment_option" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                    <label for="onetime" class="py-4 ml-2 w-full text-sm font-medium text-gray-900 dark:text-gray-300">Onetime</label>
                </div>
                <div class="flex items-center pl-4">
                    <input <?php if(old('payment_option') && old('payment_option') === 'recurring'): ?> checked <?php endif; ?>
                     onchange="togglePaymentOption(event)" id="recurring" type="radio" value="recurring" name="payment_option" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600">
                    <label for="recurring" class="py-4 ml-2 w-full text-sm font-medium text-gray-900 dark:text-gray-300">Recurring</label>
                </div> 
            </div>
            <div id="onetime_payment_option" 
                class="<?php if(old('payment_option') && old('payment_option') === 'recurring'): ?> hidden <?php else: ?> grid <?php endif; ?> gap-6 mb-6 md:grid-cols-2">
                <div>
                    <label for="onetime_cost" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Onetime Cost</label>
                    <input type="text" name="onetime_cost" id="onetime_cost" 
                        value="<?php echo e(old('onetime_cost')); ?>"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <?php if($errors->has('onetime_cost')): ?>
                        <span class="text-red-400 mt-1 text-sm"><?php echo e($errors->first('onetime_cost')); ?></span>
                    <?php endif; ?>
                </div> 
            </div>
            <div id="recurring_payment_option" class="<?php if(old('payment_option') && old('payment_option') === 'recurring'): ?> grid <?php else: ?> hidden <?php endif; ?> gap-6 mb-6 md:grid-cols-2">
                <div>
                    <label for="daily_cost" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Daily Cost</label>
                    <input type="text" name="daily_cost" id="daily_cost" 
                        value="<?php echo e(old('daily_cost')); ?>"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <?php if($errors->has('daily_cost')): ?>
                        <span class="text-red-400 mt-1 text-sm"><?php echo e($errors->first('daily_cost')); ?></span>
                    <?php endif; ?>
                </div>
                <div>
                    <label for="weekly_cost" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Weekly Cost</label>
                    <input type="text" name="weekly_cost" id="weekly_cost" 
                        value="<?php echo e(old('weekly_cost')); ?>"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <?php if($errors->has('weekly_cost')): ?>
                        <span class="text-red-400 mt-1 text-sm"><?php echo e($errors->first('weekly_cost')); ?></span>
                    <?php endif; ?>
                </div> 
                <div>
                    <label for="monthly_cost" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Monthly Cost</label>
                    <input type="text" name="monthly_cost" id="monthly_cost" 
                        value="<?php echo e(old('monthly_cost')); ?>"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <?php if($errors->has('monthly_cost')): ?>
                        <span class="text-red-400 mt-1 text-sm"><?php echo e($errors->first('monthly_cost')); ?></span>
                    <?php endif; ?>
                </div> 
                <div>
                    <label for="yearly_cost" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Yearly Cost</label>
                    <input type="text" name="yearly_cost" id="yearly_cost" 
                        value="<?php echo e(old('yearly_cost')); ?>"
                        class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <?php if($errors->has('yearly_cost')): ?>
                        <span class="text-red-400 mt-1 text-sm"><?php echo e($errors->first('yearly_cost')); ?></span>
                    <?php endif; ?>
                </div> 
            </div>
            <div class="grid gap-6 mb-6 md:grid-cols-2">
                <div>
                    <label for="billing_currency" class="block mb-2 text-sm font-medium text-gray-900 dark:text-gray-300">Billing Currency</label>
                    <select name="billing_currency" id="billing_currency" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                        <?php $__currentLoopData = $currency_codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($currency->currency_code); ?>"><?php echo e($currency->currency_code); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('billing_currency')): ?>
                        <span class="text-red-400 mt-1 text-sm"><?php echo e($errors->first('billing_currency')); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <input type="hidden" name="allow_trial" id="allow_trial" value="0">
           
            <button type="submit" class="text-white bg-teal-700 hover:bg-teal-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Save</button>
        </form>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /var/www/html/alphatribesignals/resources/views/groups/payment_option.blade.php ENDPATH**/ ?>