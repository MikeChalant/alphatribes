<?php

namespace App\Http\Controllers\Api;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Carbon\Carbon;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $request->validate([
            'country_code' => ['required','string','max:5'],
            'phone_no' => ['required','string','max:20','unique:users,phone_no']
        ]);

        $user = new User();
        $user->country_code = $request->country_code;
        $user->phone_no = $request->phone_no;
        $user->otp = mt_rand(1111,9999);
        $user->otp_expires =  Carbon::now()->addHours(2);
        $user->save();
        $data = ['message'=>'OTP expires in 2 hours', 'OTP'=>$user->otp,'phone_no'=>$user->phone_no];
        return response()->json($data, 201);
    }

    public function confirmPhone(Request $request)
    {
        $request->validate(['otp'=>['required','numeric']]);
        $user = User::where('phone_no', $request->phone_no)->where('otp', $request->otp)->first();
        if(empty($user)){
            return response()->json(['error'=>'Invalid user'], 404);
        }

        // clear otp
        $user->otp = null;
        $user->otp_expires = null;
        $user->save();

        // Create access token
        $token = $user->createToken('Access Token');

        return response(['access_token'=>$token->accessToken], 201);
    }

    public function resendConfirmPhone(Request $request)
    {
        $user = User::where('phone_no', $request->phone_no)->first();
        $user->otp = mt_rand(1111,9999);
        $user->otp_expires =  Carbon::now()->addHours(2);
        $user->save();
        $data = ['message'=>'OTP expires in 2 hours', 'OTP'=>$user->otp,'phone_no'=>$user->phone_no];
        return response()->json($data, 201);
    }
}
