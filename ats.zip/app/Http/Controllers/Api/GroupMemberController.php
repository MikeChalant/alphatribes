<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\GroupUser;
use App\Models\PaymentDetail;
use App\Models\Subscription;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;

class GroupMemberController extends Controller
{
    // Add multiple members by group owner/admin
    public function addMembers(Request $request)
    {
        for($i = 0; $i < count($request->user_id); $i++){
            //Check if user already exists in group
            $user = GroupUser::where('user_id', $request->user_id[$i])->where('group_id', $request->group_id)->first();
            if($user){
                continue;
            }
            $groupUser = new GroupUser();
            $groupUser->group_id = $request->group_id;
            $groupUser->user_id = $request->user_id[$i];
            $groupUser->role = null;
            $groupUser->save();
        }
        
        return response()->json(['message'=>'Members saved'], 201);
    }

    
    // Join free group
    public function joinFreeGroup(Request $request)
    {
        //Check if user already exists in group
        $user = GroupUser::where('user_id', $request->user_id)->where('group_id', $request->group_id)->first();
        if($user){
            return response()->json(['message'=>'Already a member'], 200);
        }
        $groupUser = new GroupUser();
        $groupUser->group_id = $request->group_id;
        $groupUser->user_id = $request->user_id;
        $groupUser->role = null;
        $groupUser->save();

        return response()->json(['message'=>'join successful'], 201);

    }

    // Subscribe to a paid group
    public function joinPaidGroup(Request $request)
    {
        //Check if user already exists in group
        $user = GroupUser::where('user_id', $request->user_id)->where('group_id', $request->group_id)->first();
        if($user){
            return response()->json(['message'=>'Already a member'], 200);
        }
        $groupUser = new GroupUser();
        $groupUser->group_id = $request->group_id;
        $groupUser->user_id = $request->user_id;
        $groupUser->role = null;
        $groupUser->save();

        $subscription = new Subscription();
        $subscription->user_id = $request->user_id;
        $subscription->group_id = $request->group_id;
        $subscription->plan = $request->plan;
        $subscription->subscription_start = Carbon::now();
        $subscription->subscription_end = $this->subscriptionEnd($request->plan);
        $subscription->save();
        return response()->json(['subscription_id'=>$subscription->id], 201);
    }

    public function paymentDetail(Request $request)
    {
        $request->validate([
            'first_name' => ['required','string'],
            'last_name' => ['required','string'],
            'email' => ['required','email'],
            'card_number' => ['required','string','min:10','max:20'],
            'expiration_date' => ['required','date'],
            'cvv' => ['required','string','min:3','max:5'],
            'subscription_id' => ['required','numeric']
        ]);

        // Get user Id
        $subscription = Subscription::find($request->subscription_id);

        $paymentDetail = new PaymentDetail();
        $paymentDetail->user_id = $subscription->user_id;
        $paymentDetail->first_name = $request->first_name;
        $paymentDetail->last_name = $request->last_name;
        $paymentDetail->email = $request->email;
        $paymentDetail->card_number = $request->card_number;
        $paymentDetail->expiration_date = $request->expiration_date;
        $paymentDetail->cvv = $request->cvv;
        $paymentDetail->save();

        // Process card payment

    }

    // Determine when the subscription ends
    private function subscriptionEnd($plan)
    {
        switch($plan){
            case $plan === 'onetime':
                return null;
            case $plan === 'daily':
                return Carbon::now()->addDay(1);
            case $plan === 'weekly':
                return Carbon::now()->addDays(7);
            case $plan === 'monthly':
                return Carbon::now()->addMonth(1);
            case $plan === 'yearly':
                return Carbon::now()->addYear(1);
        }
    }
   
}
