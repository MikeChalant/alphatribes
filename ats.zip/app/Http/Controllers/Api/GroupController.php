<?php

namespace App\Http\Controllers\Api;

use App\Models\Group;
use App\Models\GroupUser;
use Illuminate\Http\Request;
use App\Models\GroupCategory;
use App\Http\Controllers\Controller;
use Intervention\Image\Facades\Image;

class GroupController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $groups = Group::paginate(20);
        return response()->json(['groups'=>$groups], 200);
    }

    /**
     * Show group category list.
     *
     * @return \Illuminate\Http\Response
     */
    public function groupCategories()
    {
        $categories = GroupCategory::get();
        return response()->json(['categories'=>$categories]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'group_name' => ['required','string','max:35'],
            'category_id' => ['required','numeric'],
            'group_image' => ['nullable','mimes:png,jpg,gif,jpeg'],
            'description' => ['nullable','string','max:255'],
            'support_email' => ['nullable','email'],
            'lintree_website_url' => ['nullable','url'],
            'paid_group' => ['required','numeric']
        ]);

        // upload Image
        if($request->hasFile('group_image')){
            $orignalName = $request->file('group_image')->getClientOriginalName();
            $fileExt = $request->file('group_image')->getClientOriginalExtension();
            $fileName = pathinfo($orignalName, PATHINFO_FILENAME);
            $imageName = time().'_'.$fileName.'.'.$fileExt;

            $imageFolder = 'images/group_profile';
            if(!is_dir(public_path($imageFolder)))
                mkdir(public_path($imageFolder), 0777);

            Image::make($request->file('group_image')->getRealPath())
                ->fit(350,350)
                ->save($imageFolder.'/'.$imageName);
        }

        $group = new Group();
        $group->group_name = $request->group_name;
        $group->user_id = auth()->id();
        $group->group_category_id = $request->category_id;
        $group->description = $request->description;
        $group->support_email = $request->support_email ?? null;
        $group->lintree_website_url = $request->website ?? null;
        $group->paid_group = $request->paid_group;
        $group->group_type = ((int)$request->paid_group === 1) ? GROUP::GROUP_PRIVATE : GROUP::GROUP_PUBLIC;
        $group->image = ($request->hasFile('group_image')) ? $imageName : null;
        $group->save();

        // Add owner to group members
        $groupUser = new GroupUser();
        $groupUser->group_id = $group->id;
        $groupUser->user_id = auth()->id();
        $groupUser->role = GroupUser::GROUP_ROLE_OWNER;
        $groupUser->save();

        return response()->json(['group_id'=>$group->id], 201);
    }

    // Search group using name and category as query string
    public function search(Request $request)
    {
        $groups = Group::where('group_name', 'like', $request->group_name .'%')
            ->where('group_category_id', $request->category_id)->get();

        if(!count($groups)){
            return response()->json(['message'=>'No group found'], 200);
        }
        
        return response()->json(['groups'=>$groups], 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function savePaymentOption(Request $request, $id)
    {
        if($request->payment_option === 'onetime'){
            $request->validate([
                'payment_option' => ['required','string','max:20'],
                'onetime_cost' => ['required','numeric','min:0.01'],
            ]);
        }else{
            $request->validate([
                'payment_option' => ['required','string','max:20'],
                'daily_cost' => ['required','numeric','min:0.01'],
                'weekly_cost' => ['required','numeric','min:0.01'],
                'monthly_cost' => ['required','numeric','min:0.01'],
                'yearly_cost' => ['required','numeric','min:0.01'],
            ]);
        }

        $group = Group::where('id', $id)->first();
        if(empty($group)){
            return response()->json(['error'=>'Unknown group id'], 404);
        }
        $group->payment_type = $request->payment_option;
        $group->onetime_cost = $request->onetime_cost ?? null;
        $group->daily_cost = $request->daily_cost ?? null;
        $group->weekly_cost = $request->weekly_cost ?? null;
        $group->monthly_cost = $request->monthly_cost ?? null;
        $group->yearly_cost = $request->yearly_cost ?? null;
        $group->billing_currency = $request->billing_currency;
        $group->save();
        
        return response()->json(['group_id'=>$group->id], 201);
    }

    public function saveTrial(Request $request, $id)
    {
        $request->validate(['trial_period'=>['required','numeric','min:1']]);
        $group = Group::where('id', $id)->first();
        if(empty($group)){
            return response()->json(['error'=>'Unknown group id'], 404);
        }
        $group->trial_duration = $request->trial_period;
        $group->save();
        return response()->json(['group_id'=>$group->id], 201);

    }

    public function saveStripeConnect(Request $request, $id)
    {
        $request->validate(['stripe_connect_email'=>['required','email','max:100']]);
        $group = Group::where('id', $id)->first();
        if(empty($group)){
            return response()->json(['error'=>'Unknown group id'], 404);
        }
        $group->stripe_connect_email = $request->stripe_connect_email;
        $group->save();
        return response()->json(['group_id'=>$group->id], 201);
    }
}
