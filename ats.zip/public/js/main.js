function confirmDelete(event, formElement, title) {
    event.preventDefault();
    Notiflix.Confirm.show(
        title,
        "Are you sure?",
        "Yes",
        "Cancel",
        function okCb() {
            document.querySelector(`#${formElement}`).submit();
        }
    );
}

function permitAction(event, title, url) {
    event.preventDefault();
    Notiflix.Confirm.show(
        title,
        "Are you sure?",
        "Yes",
        "Cancel",
        function okCb() {
            window.location = url;
        }
    );
}

function togglePaymentOption(event) {
    let onetimeEl = document.querySelector("#onetime_payment_option");
    let recurringEl = document.querySelector("#recurring_payment_option");
    if (event.target.value === "onetime") {
        recurringEl.classList.toggle("grid");
        recurringEl.classList.toggle("hidden");
        onetimeEl.classList.toggle("hidden");
        onetimeEl.classList.toggle("grid");
    }

    if (event.target.value === "recurring") {
        onetimeEl.classList.toggle("hidden");
        onetimeEl.classList.toggle("grid");
        recurringEl.classList.toggle("grid");
        recurringEl.classList.toggle("hidden");
    }
}

function allowTrial(event) {
    event.preventDefault();
    let trialEl = document.querySelector("#allow_trial");
    let formEl = document.querySelector("#allow_trial_form");
    Notiflix.Confirm.show(
        "Trial Period",
        "Do you want to allow trial?",
        "Yes",
        "Cancel",
        function okCb() {
            trialEl.value = 1;
            formEl.submit();
        },
        function cancelCb() {
            trialEl.value = 0;
            formEl.submit();
        }
    );
}
